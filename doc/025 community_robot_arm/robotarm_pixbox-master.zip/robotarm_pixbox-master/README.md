# robotarm_pixbox
Script to control ftobler robot arm via RaspberryPi with Xbox360 Controller

Must be in use with xboxdrv library and FRC4564 class: https://github.com/FRC4564/Xbox

