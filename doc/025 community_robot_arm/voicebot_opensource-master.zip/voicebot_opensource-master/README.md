# voicebot_opensource
voice control programme to direct robot arm designed by https://github.com/ftobler/robotArm/.
Robot center is (0,0). Working range -/+ 90 degrees. 
No boundary limit is in place, hence be careful of what order you send to the arm to avoid massive step loss.

python libraries required: 
https://pypi.org/project/SpeechRecognition/
https://pypi.org/project/gTTS/
https://pypi.org/project/pyserial/

init & configure your arm setting accordingly and run voicebot_opensource.py 
