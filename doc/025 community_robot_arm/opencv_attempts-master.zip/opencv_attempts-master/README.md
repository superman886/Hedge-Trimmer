# opencv_attempts
initial trial scripts to learn opencv 

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/P7VAKhC102g/0.jpg)](https://www.youtube.com/watch?v=P7VAKhC102g)
